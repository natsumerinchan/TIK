#!/bin/bash

#
#    Copyright (C) 2022-yeliqin666
#    2022-02-01 13:19:06 
#

PROJECT_DIR=$(pwd)
if [[ -f ${PROJECT_DIR}/system/system/build.prop ]]; then
	SYSTEM_DIR="${PROJECT_DIR}/system/system"
else
	SYSTEM_DIR="${PROJECT_DIR}/system"
fi
SYSTEM_EXT_DIR="${PROJECT_DIR}/system_ext"
PRODUCT_DIR="${PROJECT_DIR}/product"
VENDOR_DIR="${PROJECT_DIR}/vendor"
SHELL_DIR="$(cd $(dirname $0); pwd)"


export USER=$(echo "$(whoami | gawk '{ print $1 }')")

droidver=$(cat $SYSTEM_DIR/build.prop | grep "ro.build.version.release=" | cut -d"=" -f 2)
Device=$(cat ${PROJECT_DIR}/vendor/build.prop | grep "ro.product.vendor.device=" | cut -d"=" -f 2)

# Fstab patches

if [ -f "$PROJECT_DIR/vendor_boot/ramdisk/first_stage_ramdisk/fstab.qcom" ] ; then
fstab="$PROJECT_DIR/vendor_boot/ramdisk/first_stage_ramdisk/fstab.qcom"
elif [ -f "$PROJECT_DIR/boot/ramdisk/fstab.qcom" ]  ; then
fstab="$PROJECT_DIR/boot/ramdisk/fstab.qcom"
fi

if [ -f "dtbo.img" ];then 
	echo "【dtbo.img】开始去除 AVB校验"
	sed -i 's/\\x69\\x74\\x2C\\x61\\x76\\x62/\\x69\\x74\\x2C\\x00\\x00\\x00/g' "dtbo.img"
fi

# Fstab patches
if [ "$Device" != "grus" ] && [ "$Device" != "perseus" ] && [ "$Device" != "gaucuin" ] ;then 
echo -en "\n开始去除AVB校验与data加密..."
	${su} sed -i 's/secure=0/secure=1/' $VENDOR_DIR/default.prop
	${su} sed -i 's/,avb_keys=\/avb\/q-gsi.avbpubkey:\/avb\/r-gsi.avbpubkey:\/avb\/s-gsi.avbpubkey//g' $fstab
	${su} sed -i 's/fileencryption=/encryptable=/g' $fstab
	${su} sed -i 's/forceencrypt=/encryptable=/' $fstab
	${su} sed -i 's/forcefdeorfbe=/encryptable=/' $fstab
	${su} sed -i 's/.dmverity=true/.dmverity=false/' $fstab
	${su} sed -i 's/,avb=vbmeta_system//g' $fstab
	${su} sed -i 's/,avb=vbmeta//g' $fstab
	${su} sed -i 's/,avb//g' $fstab
cp -afrv $fstab $PROJECT_DIR/vendor/etc
echo -en "\n成功！"
fi

echo -en "\n开始系统精简与调整操作..."
for i in $(cat rm.txt)
do
rm -fr $i
done

mv -f $PROJECT_DIR/product/app/aiasst_service/ $SYSTEM_DIR/data-app/
mv -f $PROJECT_DIR/product/app/talkback/ $SYSTEM_DIR/data-app/
mv -f $SYSTEM_DIR/priv-app/Browser/ $SYSTEM_DIR/data-app/
mv -f $SYSTEM_DIR/priv-app/MIUIVideo/ $SYSTEM_DIR/data-app/
mv -f $SYSTEM_DIR/priv-app/MiuiVideo/ $SYSTEM_DIR/data-app/
mv -f $SYSTEM_DIR/app/MIUIMusic/ $SYSTEM_DIR/data-app/


echo -en "\n精简完成！"
if [[ -x $(command -v apt) ]]; then
	if [[ ! -x "$(command -v java)" ]]; then
		${su}apt install openjdk-14-jdk
	fi
fi

sed -i '1 i\#Made by TIK-Yeliqin666' $SYSTEM_DIR/build.prop
echo -en "\n完成！"
echo -en "\n去除10s限制和主题破解项需要微调，暂不放置"

if [ "$droidver" -lt "12" ];then
echo -en "\n开始破解卡米..."
ApkTool="java -jar $SHELL_DIR/apktool/apktool.jar"

if [[ -x $(command -v apt) ]]; then
	if [[ ! -x "$(command -v java)" ]]; then
		${su} apt install openjdk-14-jdk
	fi
fi

${su} rm -rf $SHELL_DIR/services 2>/dev/null

			$ApkTool d -r -o $SHELL_DIR/services $SYSTEM_DIR/framework/services.jar -f

			if [ -d $SHELL_DIR/services ]; then
				Crack_File=$(find $SHELL_DIR/services/ -type f -name '*.smali' 2>/dev/null | xargs grep -rl '.method private checkSystemSelfProtection(Z)V' | sed 's/^\.\///' | sort)
				sed -i '/^.method private checkSystemSelfProtection(Z)V/,/^.end method/{//!d}' $Crack_File
				sed -i -e '/^.method private checkSystemSelfProtection(Z)V/a\    .locals 1\n\n    return-void' $Crack_File
				$ApkTool b -o $SYSTEM_DIR/framework/services.jar $SHELL_DIR/services -f
				${su} rm -rf $SHELL_DIR/services 2>/dev/null
				${su} chown -hR $USER:$USER $SYSTEM_DIR/framework/services.jar
				${su} chmod -R a+rwX $SYSTEM_DIR/framework/services.jar
			fi

echo -en "\n破解完成！"
fi
echo -en "\n纯净包制作完成!"
sleep 5
